# w0uFF Together — source preview 0.4.0

A custom, **uncompiled** fork of the GPL-3.0 UnchainedTogether trainer. Original author:
[xiaoxiao921](https://github.com/xiaoxiao921/UnchainedTogether). Original LICENSE and
project references are retained.

## Included

- In-game title and Windows resources renamed to **w0uFF Together**.
- **Manage Features** panel with persistent activation flags in the existing TOML GUI config under
  `[wouff_features]`. Checkboxes **disable behaviour and hide controls**, rather than deleting
  the implementation from the source.
- Built-in feature gates: Fly mode, Free camera, Teleport, Unlock wings, Hitbox debug.
- **New Coordinates HUD** module. Off by default. Displays the latest captured player position
  using the game's existing main-thread snapshot, never by following an Unreal pointer in the renderer.
- `src/features/feature_registry.hpp`: C++23 header-only registry with metadata and atomic flags.

**Important:** This release is source only. We have **not** compiled or tested a Windows DLL.
The project's bundled Unreal SDK and signature scans were generated for an older game version.
The provided November 2026 `d3d12.dll` was examined as a reference, **not patched, reverse-engineered
for offsets, replaced, or redistributed**. It does not establish compatibility for this fork.

## Runtime functionality vs. removing from source

- **Disable**: open INSERT > w0uFF Together > Manage Features; uncheck a module. This hides
  its UI and blocks its requests/hotkeys, and persists across restarts.
- **Source removal**: delete the code for an unused feature, including every call site identified
  by its feature ID; deleting a registry entry alone does **not** remove its compiled code.
- Free camera is a **toggle** in the game: disabling the module stops future hotkey requests but
  will **not** force a second toggle if the debug camera is currently active. Toggle it off in game
  before disabling.
- The legacy experimental TAS code is present in the original project and has **not** been
  refactored into the feature registry.

## How to add our next feature

1. Add an enum entry to `wouff::feature_id` and its corresponding row to `wouff::features` in
   `src/features/feature_registry.hpp`. Keep both in the same order.
2. Put behaviour in a separate source module, e.g. `src/features/my_feature.hpp/.cpp`.
3. Gate ALL hotkeys, draw calls and game-thread requests with
   `wouff::feature_registry::enabled(wouff::feature_id::my_feature)`.
4. For Unreal interactions, queue work to the **game thread**. The ImGui renderer should only
   read safe POD snapshots and issue requests.
5. Features appear automatically in Manage Features and are persisted via TOML.
6. Compile with **Windows + MSVC, CMake 3.24+, the original dependencies**, and a verified
   SDK/signatures for the exact Chained Together build. Test in solo first.

## Verification

- `tests/feature_registry_test.cpp` exercises default flags and on/off changes outside Windows.
- Testing the game and compiling with Unreal dependencies is still required.
- Keep your original `d3d12.dll` backed up; do not install this source ZIP as if it were a DLL.

## v0.3.0 training checkpoints

See `PRACTICE_CHECKPOINTS.md` for the known-cut catalog and calibration workflow.
Vanilla movement is required: the previous synthetic spacebar injection and its hotkey are removed.

## v0.4.0 catalog

20 slots with per-cut source-evidence labels, solo/duo practice tips, guide URL copy button, compatible saved IDs and uncalibrated new positions. See `GUIDE_CUTS_FR.md`. No full DLL has been built.

## Vanilla jump removal v0.4.0

The previous synthetic spacebar (`keybd_event`) bunny-hop code, its feature registry entry, its hotkey and its obsolete jump hook have been removed. Native game jump remains. Legacy TAS input replay code is still present from upstream and has NOT been validated or fully removed. Do not enable those old hotkeys while training.


## v0.4.1 — Vanilla-first safety

The unused replay/TAS capture and playback block has been removed, along with synthetic movement and jump injection. Vanilla movement and jump code is not patched by this fork. Fly is an explicit optional module. The checkpoint path has a thread-safe position queue and preserves current actor rotation. No teammate teleportation or chain reset is implemented. All runtime behavior remains unverified on Chained Together 1.11.2.
