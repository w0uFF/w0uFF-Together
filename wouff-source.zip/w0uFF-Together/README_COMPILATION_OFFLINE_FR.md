# w0uFF Together — Sources complètes hors ligne, compilation Windows en attente

**Version de source :** 0.4.1 (patchs de sécurité de téléportation / suppression des injections de sauts et TAS de l'étape précédente). **Dépendances :** 17/17 intégrées. **DLL compilée : aucune**.

## État confirmé

1. Les 17 archives de dépendance sont décompressées dans `third_party/`; PolyHook contient AsmJit, AsmTK, Zydis et Zydis/dependencies/zycore.
2. La configuration CMake complète et le contrôle des dépendances ont été validés **hors ligne sur Linux**.
3. Trois tests C++ indépendants ont été compilés et exécutés : 3/3 réussis.
4. La compilation du projet complet **sur Linux** échoue dans ImGui DirectX 11 sur `d3d11.h` (Windows SDK indisponible). Ce comportement ne permet pas de conclure à un échec du build **sur Windows**.
5. L'ancien SDK Unreal Engine inclus dans les sources n'a pas été validé pour le jeu 1.11.2. Fly, checkpoints F8 et synchronisation coop sont **non testés dans le jeu**. Les coordonnées de cuts demeurent à calibrer.

## Windows CI (aucune compilation manuelle demandée à l'utilisateur)

Un dépôt GitHub **dédié à ce mod** est nécessaire pour exécuter le workflow de compilation sans utiliser un dépôt sans rapport. Le fichier `.github/workflows/wouff-windows-build.yml` est prêt à être placé **à la racine du dépôt**. La source extraite peut être ajoutée dans le dossier `w0uFF-Together` du dépôt. **Plus simple depuis le navigateur :** envoyer à la racine du dépôt les trois archives préparées `wouff-source.zip`, `wouff-vendor-1.zip`, `wouff-vendor-2.zip` (chacune inférieure à 20 Mio). Le workflow les assemble automatiquement au lancement. Il faut également placer `.github/workflows/wouff-windows-build.yml` **à la racine du dépôt**, et non à l'intérieur d'un ZIP. Après le lancement manuel de l'action `w0uFF Together - Windows build (artifact only)`, si la compilation réussit, l'artefact est `w0uFF-Together-unverified-Windows-DLL` contenant `d3d12.dll`. Le workflow contrôle le format PE x64 et l'export proxy D3D12.

Le workflow peut encore échouer à cause des signatures Unreal/du SDK ou d'erreurs de compilation MSVC. Ce résultat devra être corrigé sur les logs réels, **pas présumé**. Aucun workflow n'a été lancé à ce jour.

## Vérification en jeu, après une vraie DLL compilée

1. Faire une copie de sauvegarde de `d3d12.dll` actuellement fonctionnelle (tierce).
2. Installer **uniquement** notre nouveau `d3d12.dll` dans `ChainedTogether/Binaries/Win64`, puis lancer Chained Together en DX12.
3. Vérifier que le jeu démarre, que `INSERT` ouvre le menu w0uFF, que Fly `F7` fonctionne et que l'enregistrement/rappel d'un checkpoint avec `F8` fonctionne sur une plateforme sûre.
4. Vérifier que le saut et la vitesse restent vanilla. Dans une partie privée avec le collègue, vérifier en plus que le téléport ne déstabilise pas la chaîne; aucune téléportation du partenaire n'est actuellement implémentée.
5. Noter pour chaque étape succès/échec et tout crash avec log. **Une DLL tierce fonctionnelle n'est pas une validation de notre fork.**

Le code source du mod conserve sa licence GPL-3.0, et les bibliothèques tierces conservent leurs propres licences.
