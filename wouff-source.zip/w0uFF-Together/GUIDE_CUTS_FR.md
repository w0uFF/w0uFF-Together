# w0uFF Together — Guides de cuts SOLO / DUO (v0.4.0)

**Source** : catalogue de marqueurs et conseils, PAS une base de coordonnees X/Y/Z ni un guide de touches garanti.
Un nom « documente » signifie uniquement que la communaute a mentionne ce cut ou la technique ; la position exacte et la variante duo ne sont pas validees.
Les conseils solo/duo sont des procedures **proposees pour l entrainement** lorsqu une source ne fournit pas un tutoriel pas a pas.
Le fork ne modifie volontairement ni vitesse, ni hauteur de saut. Les techniques CBO exploitent la physique native du jeu. Ces guides communautaires sont pour la plupart anterieurs a la version 1.11.2 : compatibilite et geste precis a revérifier en jeu.
**Aucune teleportation a deux joueurs n est implementee** : seule la position du joueur local est envoyee au jeu. Les objets dynamiques ne sont pas reinitialises.

## Catalogue par zone

| Zone | Preset | Niveau de preuve | Reference |
|---|---|---|---|
| Hell | `hell_cliffs` — Hell Cliffs — Mountain Skip | nom documente | [Voir](https://www.speedrun.com/Chained_Together/news) |
| Hell | `hell_entry` — Hell — Autres cuts (emplacement libre) | emplacement libre | [Voir](https://www.youtube.com/watch?v=WKHH4LyvD-I&t=0s) |
| Hell | `hell_car_cube` — Car Race — Cube / Timing | nom mentionne | [Voir](https://www.speedrun.com/Chained_Together/forums/8p54x) |
| City | `city_cut_01` — City — Cut 01 | slot video | [Voir](https://www.youtube.com/watch?v=QNm-SxKDle4) |
| City | `city_cut_02` — City — Cut 02 | slot video | [Voir](https://www.youtube.com/watch?v=QNm-SxKDle4) |
| City | `city_cut_03` — City — Cut 03 | slot video | [Voir](https://www.youtube.com/watch?v=QNm-SxKDle4) |
| City | `city_cut_04` — City — Cut 04 (Easy) | slot video | [Voir](https://www.youtube.com/watch?v=QNm-SxKDle4&t=39s) |
| City | `city_cut_05` — City — Cut 05 (optionnel) | emplacement libre | [Voir](https://www.youtube.com/watch?v=QNm-SxKDle4) |
| City | `city_pre_train` — Avant le train — Wall / Spam Cut | nom mentionne | [Voir](https://www.speedrun.com/Chained_Together/forums/yaxpi) |
| Temple | `temple_bubble` — Temple — Bubble Skip | nom documente | [Voir](https://www.speedrun.com/Chained_Together/news) |
| Temple | `temple_mountain` — Temple — Mountain Route | nom documente | [Voir](https://www.speedrun.com/Chained_Together/news) |
| Temple | `temple_ladder` — Temple — Ladder / Chain Grind | technique documentee | [Voir](https://www.speedrun.com/Chained_Together/news) |
| Temple | `temple_spam` — Temple — Spam Cut | nom documente | [Voir](https://www.speedrun.com/Chained_Together/forums/yaxpi) |
| Shrine | `shrine_cut` — Asian Shrine — Cuts (emplacement libre) | emplacement libre | [Voir](https://www.youtube.com/watch?v=WKHH4LyvD-I&t=596s) |
| Deities | `deities_zeus` — Deities — Zeus Skip | nom documente | [Voir](https://www.speedrun.com/Chained_Together/news) |
| Deities | `deities_cut` — Deities — Autres cuts (emplacement libre) | emplacement libre | [Voir](https://www.youtube.com/watch?v=WKHH4LyvD-I&t=734s) |
| Garden | `garden_cut` — Garden — Cuts (emplacement libre) | emplacement libre | [Voir](https://www.youtube.com/watch?v=WKHH4LyvD-I&t=835s) |
| Routes | `route_window` — Window Skip — Variante de route | nom mentionne | [Voir](https://www.speedrun.com/Chained_Together/runs/mewql10m) |
| Routes | `route_helicopter` — Helicopter Skip | nom mentionne | [Voir](https://www.speedrun.com/Chained_Together/forums/jwi5y) |
| Techniques | `tech_bumper` — Bumper / Trampoline Buffer | technique documentee | [Voir](https://www.speedrun.com/Chained_Together/news) |

## Conseils pour chaque cut

### Hell Cliffs — Mountain Skip (`hell_cliffs`)
- **Fiabilite :** nom documente. Nom cite explicitement dans les regles speedrun. Trajet exact a confirmer visuellement.
- **Solo (entrainement propose) :** Repere le contournement de la montagne dans la zone Hell Cliffs. Filme tes essais et place le checkpoint sur un sol ferme avant la tentative; ajuste approche et angle sans modifier le saut.
- **Duo (entrainement propose, non teste) :** Placez-vous sur une plateforme stable a deux. Conservez du mou dans la chaine avant le depart; essayez un passage l un apres l autre. Strategie proposee, non verifiee pour ce cut.
- **Reference :** https://www.speedrun.com/Chained_Together/news

### Hell — Autres cuts (emplacement libre) (`hell_entry`)
- **Fiabilite :** emplacement libre. Emplacement libre correspondant au chapitre Hell de la video, pas un cut nomme.
- **Solo (entrainement propose) :** Regarde le chapitre Hell, identifie le depart exact puis capture-le; aucun geste precis n est atteste pour cet emplacement.
- **Duo (entrainement propose, non teste) :** Calibrez chacun votre position sur une zone sure avant de comparer les trajectoires.
- **Reference :** https://www.youtube.com/watch?v=WKHH4LyvD-I&t=0s

### Car Race — Cube / Timing (`hell_car_cube`)
- **Fiabilite :** nom mentionne. La communaute mentionne le cube de la course automobile; methode exacte non documentee.
- **Solo (entrainement propose) :** Place le point de depart avant le cube mobile, observe son cycle et note le timing de tes tentatives; ne suppose pas que le cycle est reinitialise par la TP.
- **Duo (entrainement propose, non teste) :** Les deux joueurs attendent le meme cycle et annoncent le depart; recommencez au besoin en recreant une session.
- **Reference :** https://www.speedrun.com/Chained_Together/forums/8p54x

### City — Cut 01 (`city_cut_01`)
- **Fiabilite :** slot video. Numero de slot de la video City, correspondance exacte a confirmer.
- **Solo (entrainement propose) :** Repere la premiere sequence dans la video City, capture le point juste avant le saut et compare position, angle et impulsion.
- **Duo (entrainement propose, non teste) :** Faites un essai de reperage chacun; puis essayez un depart coordonne avec la chaine non tendue.
- **Reference :** https://www.youtube.com/watch?v=QNm-SxKDle4

### City — Cut 02 (`city_cut_02`)
- **Fiabilite :** slot video. Numero de slot de la video City, correspondance exacte a confirmer.
- **Solo (entrainement propose) :** Repere la deuxieme sequence dans la video City et capture un depart sur sol stable; refais toujours le meme mouvement.
- **Duo (entrainement propose, non teste) :** Communiquez le moment du saut et evitez de tendre brusquement la chaine.
- **Reference :** https://www.youtube.com/watch?v=QNm-SxKDle4

### City — Cut 03 (`city_cut_03`)
- **Fiabilite :** slot video. Numero de slot de la video City, correspondance exacte a confirmer.
- **Solo (entrainement propose) :** Utilise la video City comme reference visuelle; calibre le saut avec tes propres coordonnees.
- **Duo (entrainement propose, non teste) :** Placez vos deux personnages en securite avant de recommencer; un joueur teste puis l autre.
- **Reference :** https://www.youtube.com/watch?v=QNm-SxKDle4

### City — Cut 04 (Easy) (`city_cut_04`)
- **Fiabilite :** slot video. Le guide City mentionne un Cut 4 Easy a 00:39; depart exact a relever dans la video.
- **Solo (entrainement propose) :** Visionne la sequence Cut 4 Easy a 00:39; reproduis le placement avant de sauver le depart.
- **Duo (entrainement propose, non teste) :** Reproduisez d abord le placement des deux personnages; verifiez que la chaine ne gene pas le passage.
- **Reference :** https://www.youtube.com/watch?v=QNm-SxKDle4&t=39s

### City — Cut 05 (optionnel) (`city_cut_05`)
- **Fiabilite :** emplacement libre. Emplacement supplementaire libre. Aucune cinquieme technique distincte verifiee.
- **Solo (entrainement propose) :** Affecte ce slot a une variation que tu pratiques souvent; renomme le JSON uniquement pour tes notes (l identifiant doit rester identique).
- **Duo (entrainement propose, non teste) :** Calibrez a deux depuis un endroit sans danger; le slot ne contient aucune technique attestee.
- **Reference :** https://www.youtube.com/watch?v=QNm-SxKDle4

### Avant le train — Wall / Spam Cut (`city_pre_train`)
- **Fiabilite :** nom mentionne. Un coureur decrit un autre cut avant le train avec sauts repetes.
- **Solo (entrainement propose) :** Cherche le mur situe avant le train. Reste sur le saut vanilla; travaille positionnement, cadence et bord de collision sans macro. Le forum ne fournit pas de sequence certifiee.
- **Duo (entrainement propose, non teste) :** Mettez-vous sur la meme zone de depart; un joueur teste pendant que l autre garde un appui stable. Technique duo non verifiee.
- **Reference :** https://www.speedrun.com/Chained_Together/forums/yaxpi

### Temple — Bubble Skip (`temple_bubble`)
- **Fiabilite :** nom documente. Bubble cut cite dans les regles de speedrun parmi les techniques CBO.
- **Solo (entrainement propose) :** Dans le chapitre Temple, repere la bulle et le point de contact utilise par les runners. Entraine la succession de sauts au contact avec les collisions vanilla.
- **Duo (entrainement propose, non teste) :** Avant de tenter le passage, evitez la traction de chaine sur le joueur qui effectue le saut; les variantes duo restent a confirmer.
- **Reference :** https://www.speedrun.com/Chained_Together/news

### Temple — Mountain Route (`temple_mountain`)
- **Fiabilite :** nom documente. Le passage par les montagnes du Temple est explicitement cite dans les regles.
- **Solo (entrainement propose) :** Identifie le chemin par le flanc de la montagne et entraine ses appuis successifs plutot que le chemin central.
- **Duo (entrainement propose, non teste) :** Progresser par paliers, avec une plateforme de securite commune avant chaque nouvelle section.
- **Reference :** https://www.speedrun.com/Chained_Together/news

### Temple — Ladder / Chain Grind (`temple_ladder`)
- **Fiabilite :** technique documentee. Les grinds avec sauts sur chaines et echelles sont cites par les moderateurs.
- **Solo (entrainement propose) :** Repere une echelle ou une chaine utilisable et entraine les sauts successifs aux points de collision, avec les commandes de saut integrees au jeu.
- **Duo (entrainement propose, non teste) :** En duo, la tension de la chaine peut modifier le contact. Testez un joueur puis l autre et notez les cas de desynchronisation.
- **Reference :** https://www.speedrun.com/Chained_Together/news

### Temple — Spam Cut (`temple_spam`)
- **Fiabilite :** nom documente. Le forum de speedrun decrit un spam cut de Temple et ses difficultes de cadence.
- **Solo (entrainement propose) :** Repere le mur du spam cut, maintiens le bon contact et teste le rythme de sauts avec les commandes vanilla (molette reglable dans le jeu). Evite l auto-scroll et les macros.
- **Duo (entrainement propose, non teste) :** Definissez un depart synchronise et gardez la chaine detendue; le forum porte sur le solo, pas sur une methode duo validee.
- **Reference :** https://www.speedrun.com/Chained_Together/forums/yaxpi

### Asian Shrine — Cuts (emplacement libre) (`shrine_cut`)
- **Fiabilite :** emplacement libre. Chapitre Shrine de la video, sans nom de cut individuel certifie.
- **Solo (entrainement propose) :** Visionne le chapitre Shrine a 09:56, trouve un point de depart stable puis enregistre ta position.
- **Duo (entrainement propose, non teste) :** Pour un entrainement duo, capturez chacun la position sur une plateforme assez large.
- **Reference :** https://www.youtube.com/watch?v=WKHH4LyvD-I&t=596s

### Deities — Zeus Skip (`deities_zeus`)
- **Fiabilite :** nom documente. Zeus skip explicitement cite parmi les grands skips par les moderateurs.
- **Solo (entrainement propose) :** Prends le passage de Zeus dans la video comme reference et calibre l approche. Les sources textuelles ne donnent pas une manipulation fiable pas a pas.
- **Duo (entrainement propose, non teste) :** Mettez-vous a deux sur un appui sur avant le depart; notez les reactions de la chaine. Pas de teleporation automatique du partenaire.
- **Reference :** https://www.speedrun.com/Chained_Together/news

### Deities — Autres cuts (emplacement libre) (`deities_cut`)
- **Fiabilite :** emplacement libre. Chapitre Deities de la video, sans identification d un second cut nomme.
- **Solo (entrainement propose) :** Repere une autre technique dans le chapitre Deities et enregistre son depart; ne confonds pas avec Zeus Skip.
- **Duo (entrainement propose, non teste) :** Calibrez et synchronisez votre depart; le guide ne fournit pas de variante duo precise.
- **Reference :** https://www.youtube.com/watch?v=WKHH4LyvD-I&t=734s

### Garden — Cuts (emplacement libre) (`garden_cut`)
- **Fiabilite :** emplacement libre. Chapitre Garden de la video; depart exact et technique inconnus.
- **Solo (entrainement propose) :** Visionne la partie Garden (13:55), choisi une tentative a repeter et enregistre le depart sur un appui stable.
- **Duo (entrainement propose, non teste) :** En duo, recherchez une zone large pour les deux personnages; a verifier selon les collisions.
- **Reference :** https://www.youtube.com/watch?v=WKHH4LyvD-I&t=835s

### Window Skip — Variante de route (`route_window`)
- **Fiabilite :** nom mentionne. Nom atteste dans un commentaire de run officiel; zone et technique exacte non confirmees.
- **Solo (entrainement propose) :** Consulte la video de run liee pour reperer le Window Skip. Sauvegarde ton depart une fois reconnu. Ne pas extrapoler la trajectoire depuis le seul nom.
- **Duo (entrainement propose, non teste) :** Filmez le depart des deux personnages et identifiez le risque de traction; aucune technique duo atteste.
- **Reference :** https://www.speedrun.com/Chained_Together/runs/mewql10m

### Helicopter Skip (`route_helicopter`)
- **Fiabilite :** nom mentionne. Discussion communautaire identifiee; zone et etapes non confirmees.
- **Solo (entrainement propose) :** Visionne la demonstration si elle est disponible dans le fil, puis calibre un endroit sur avant la tentative.
- **Duo (entrainement propose, non teste) :** Verifiez en prive si le mouvement du premier joueur entraine le second; chaine et scene non reinitialisees automatiquement.
- **Reference :** https://www.speedrun.com/Chained_Together/forums/jwi5y

### Bumper / Trampoline Buffer (`tech_bumper`)
- **Fiabilite :** technique documentee. Technique de rebond citee dans les regles; ce n est pas un cut localise.
- **Solo (entrainement propose) :** Repere un trampoline, tambour ou coussin rouge et entraine le timing du rebond avec la physique vanilla. Le checkpoint ne remet pas necessairement les objets a leur etat initial.
- **Duo (entrainement propose, non teste) :** Coordonnez l ordre des rebonds et la tension de chaine. Les essais servent a etudier la physique, pas a changer vitesse ou hauteur de saut.
- **Reference :** https://www.speedrun.com/Chained_Together/news

## Calibration et precautions

1. Dans le jeu sur la carte originale, ouvre INSERT > w0uFF Practice — Known Cuts et selectionne un preset.
2. Regarde sa reference, mets-toi sur une surface stable avant la manoeuvre, puis clique Capture current position as this cut start.
3. Utilise Teleport / Repeat ou F8 pour revenir a ce point. Aucun point sans X/Y/Z calibre ne peut etre teleporte.
4. Sauvegarde partageable : `practice_checkpoints.json`. Le catalogue v0.4 conserve tous les IDs v0.3 ; les nouvelles entrees restent non calibrees.
5. En duo, calibrez une position pour chaque joueur si chacun dispose du mod, puis testez separement. **La mise en place des deux joueurs et de la chaine n est pas synchronisee**.
6. Pour comparer les essais, gardez la meme version du jeu, le meme mode et les memes conditions de depart.

### Sources consultees

- Video communautaire ALL CUTS (UPDATED) : https://www.youtube.com/watch?v=WKHH4LyvD-I
- Video City : https://www.youtube.com/watch?v=QNm-SxKDle4
- Changements des regles et techniques CBO : https://www.speedrun.com/Chained_Together/news
- Discussion du spam cut et d un cut avant le train : https://www.speedrun.com/Chained_Together/forums/yaxpi
- Discussion helicopter skip : https://www.speedrun.com/Chained_Together/forums/jwi5y
- Mention du window skip dans un run : https://www.speedrun.com/Chained_Together/runs/mewql10m
- Car Race Cube (forum index) : https://www.speedrun.com/Chained_Together/forums/8p54x

## Compatibilite et build
**Cette version contient du code source non compile uniquement.** Environnements MSVC/Windows, ReturnOfModdingBase, utfcpp et SDK/signatures de Chained Together 1.11.2 sont necessaires pour produire et valider une DLL. Ne jamais substituer un binaire tiers dans la distribution en pretendant qu il s agit du fork w0uFF Together.
