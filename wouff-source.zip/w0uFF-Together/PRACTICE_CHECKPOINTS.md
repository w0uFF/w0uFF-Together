# w0uFF Together — Practice Cut Presets (v0.4.0 source)

## Presets and evidence

The catalog now contains 20 slots, including six main map chapters and other documented techniques. Original video chapters:
Hell (00:00), City (03:54), Temple (08:25), Shrine (09:56), Deities
(12:14), and Garden (13:55).

Main guide: https://www.youtube.com/watch?v=WKHH4LyvD-I
City-specific guide: https://www.youtube.com/watch?v=QNm-SxKDle4
Speedrunning rules and techniques: https://www.speedrun.com/Chained_Together/news

The video does **not** provide reliable UE X/Y/Z coordinates. Every preset
ships **uncalibrated**, `position: null`. Names and labels include the supported community names, separate technique slots and
generic/numbered slots; this is **not** a verified exhaustive list of every cut.
Never manually replace missing coordinates with elevation figures from public
checkpoints; they are NOT 3D world positions.

## Using the menu (only after a working DLL has been built)

1. Make a backup of your existing functioning `d3d12.dll`.
2. Open the overlay with `INSERT` > `w0uFF Practice — Known Cuts`.
3. Select the cut. Use the linked guide to walk/fly to a safe starting
   platform, and put the character on the platform in the desired launch spot.
4. Click **Capture current position as this cut start**.
5. The point is written to the mod's `practice_checkpoints.json` file.
6. **Teleport / Repeat** or press **F8** to repeat from the selected cut.
7. The file may be shared with your teammate, but each player's game needs its
   own working mod and the coordinates must match the same original map.
8. **Clear this cut calibration** to remove a bad point. **Reload presets from
   JSON** to import a file edited or shared outside the game.

Only the local player is teleported by the current source implementation.
Network replication, host-only teleport restrictions, chain collision, and
whether the other player follows are **not validated**. Do not assume this
source automatically repositions both players or resets dynamic scene objects.
Teleportation can place a player in unsafe geometry or disturb chain physics.
Use a private practice session and calibrate on a safe platform.

## Files

- `practice_checkpoints.PRESET.json`: preset list as a shareable template,
  with deliberately null positions.
- `practice_checkpoints.json`: auto-created by the mod on first startup,
  written next to the project's mod data. Recalibrated positions persist.
- `src/features/practice_checkpoints.hpp`: pure C++ catalog and coordinate
  validation, independent from Windows/Unreal.
- `src/gui/gui.cpp`: UI, file IO, F8 repeat, and game-thread teleport requests.

## Status

Windows DLL compilation: **not completed**. Unreal SDK/signatures are from an
older build, so compatibility with Chained Together 1.11.2 remains unverified.
Do not install the source ZIP as a DLL.

Full French solo/duo guide: `GUIDE_CUTS_FR.md`.
