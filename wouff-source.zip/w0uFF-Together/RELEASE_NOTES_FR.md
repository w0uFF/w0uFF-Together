# w0uFF Together v0.4.1 — Source (pre-build)

## Ajouts effectues

- Correction des requetes de TP entre UI et jeu avec une mailbox verrouillee et un test de concurrence.
- Snapshot synchronise par mutex (suppression de l'utilisation de `volatile` comme mecanisme de synchronisation).
- Preservation de l'orientation actuelle au teleporte.
- Retrait du code TAS/replay, du gel du temps et des commandes synthetiques de mouvement et de saut.
- Verification de trois modules C++ autonomes en local avec CTest, et passage du workflow CI a un declenchement manuel uniquement.
- Suppression de l'ancien workflow `nightly.yml` qui publiait automatiquement une release si execute.

## Bloqueurs et limites

- Windows SDK et compilateur MSVC absents de l'environnement local ; dependances non telechargeables depuis le conteneur (DNS GitHub indisponible).
- Le build CI n'a pas ete lance ; l'ancien SDK UE reste a verifier avec Chained Together 1.11.2.
- Aucune DLL Windows du fork n'est produite. La DLL tierce n'est pas redistribuee.
- Les 20 slots incluent des emplacements libres; les coordonnees X/Y/Z restent `null`.
- Le jeu 1.11.2, les TP en solo, en duo, le chainage et la sauvegarde au runtime ne sont pas testes.

## Suite technique

La compilation doit etre realisee sur un runner Windows MSVC avec les dependances necessaires, puis les eventuelles erreurs de build corrigees. Si une DLL est produite, elle devra etre controlee et testee dans une session privee avant de la distribuer comme fonctionnelle.
