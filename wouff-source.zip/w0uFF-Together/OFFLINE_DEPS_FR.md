# Dépendances hors ligne — w0uFF Together (mise à jour du 22/11/2026)

Les **17 sources de dépendances requises par ce projet sont présentes** dans `third_party/`, y compris les quatre sous-modules de PolyHook : AsmJit, AsmTK, Zydis et Zycore. Aucune archive supplémentaire n'est demandée à l'utilisateur.

Leurs noms, nombres de fichiers et empreintes SHA-256 figurent dans `third_party/WOUFF_DEPENDENCIES_MANIFEST.json`. Les archives d'origine ont été contrôlées et extraites dans la bonne arborescence. Les versions étaient fixées par le projet CMake et les sous-modules PolyHook.

## Tests déjà réalisés

- CMake contrôle uniquement les dépendances (`WOUFF_VALIDATE_DEPS_ONLY=ON`) : **OK**.
- CMake configuration complète sur Linux en utilisant les seules sources locales (`WOUFF_USE_VENDORED_DEPS=ON`) : **OK, sans accès réseau**.
- Tests C++ du code indépendant de Windows : **3/3 OK**.
- Compilation intégrale sur Linux : **échec attendu** sur `d3d11.h`, en-tête DirectX / Windows SDK absent ici. Ce n'est plus un téléchargement de dépendance manquant.
- Compilation Windows MSVC et compatibilité Chained Together 1.11.2 : **non testées**. Aucune `d3d12.dll` du fork n'a été produite.

## Workflow prévu sur Windows

Le workflow `.github/workflows/wouff-windows-build.yml` utilise un runner Windows, MSVC et les dépendances locales : les bibliothèques GitHub n'ont plus besoin d'être téléchargées. Il vérifie le format PE x64 et l'export `D3D12CreateDevice` avant de publier une DLL de test si le build aboutit. Il reste à **exécuter** dans un dépôt du mod. Une compilation réussie ne prouvera pas à elle seule la compatibilité dans le jeu, notamment en coopération.

Voir `README_COMPILATION_OFFLINE_FR.md` pour les étapes exactes.
