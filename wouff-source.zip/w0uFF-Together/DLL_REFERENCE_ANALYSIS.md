# DLL reference (not included in the deliverable)

Uploaded archive: `D3d12 9 2 2026-11-09T03-54Z SNt0So38X.zip`

- Archive member: `d3d12.dll`
- Byte length: 15,788,032 bytes
- SHA-256: `b9055133ce5c28397e3fcd285cc4ba30268da0bfc0c1e82d5555ecf0aff0ac4f`
- PE signature: `PE\0\0` (valid), architecture: `0x8664` (AMD64)
- COFF timestamp (informational, not proof of release date): 2026-11-09T03:50:24+00:00
- Contains static ASCII references to `ChainedTogether`, `UnchainedTogether`, and `ImGui`.
- An ASCII marker `1.11.2` was not found. Lack of this string does **not** imply incompatibility.

**Limitations:** Static inspection did not extract Unreal SDK changes, hook offsets or source code.
Neither this DLL nor the fork source has been tested against Chained Together 1.11.2.
The third-party binary is deliberately excluded from the custom source package.
