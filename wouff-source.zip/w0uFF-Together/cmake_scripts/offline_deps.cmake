# w0uFF Together: use exact vendored dependency sources without network access.
# This file is intentionally included BEFORE ReturnOfModdingBase and utfcpp.
if(NOT DEFINED WOUFF_USE_VENDORED_DEPS)
    if(EXISTS "${PROJECT_SOURCE_DIR}/third_party/rom/CMakeLists.txt")
        set(WOUFF_USE_VENDORED_DEPS ON)
    else()
        set(WOUFF_USE_VENDORED_DEPS OFF)
    endif()
endif()
option(WOUFF_USE_VENDORED_DEPS "Use provided offline third_party dependency sources" ${WOUFF_USE_VENDORED_DEPS})

if(WOUFF_USE_VENDORED_DEPS)
    set(_WOUFF_VENDOR_ROOT "${PROJECT_SOURCE_DIR}/third_party")
    # FetchContent uses uppercased dependency keys (including hyphens and ++).
    foreach(_wouff_dep IN ITEMS
        rom utfcpp asynclogger cpp-semver hashmap imgui json
        lua_static sol2 magic_enum polyhook pugixml toml++)
        string(TOUPPER "${_wouff_dep}" _wouff_upper)
        set("FETCHCONTENT_SOURCE_DIR_${_wouff_upper}"
            "${_WOUFF_VENDOR_ROOT}/${_wouff_dep}" CACHE PATH
            "Pinned local sources for ${_wouff_dep}" FORCE)
        if(NOT EXISTS "${_WOUFF_VENDOR_ROOT}/${_wouff_dep}")
            message(FATAL_ERROR "w0uFF missing offline source: ${_wouff_dep}")
        endif()
    endforeach()
    # PolyHook uses git submodules. Downloaded GitHub source archives contain only empty folders.
    foreach(_wouff_required IN ITEMS
        "polyhook/asmjit/CMakeLists.txt"
        "polyhook/asmtk/CMakeLists.txt"
        "polyhook/zydis/CMakeLists.txt"
        "polyhook/zydis/dependencies/zycore/CMakeLists.txt")
        if(NOT EXISTS "${_WOUFF_VENDOR_ROOT}/${_wouff_required}")
            message(FATAL_ERROR "w0uFF missing PolyHook submodule: ${_wouff_required}. Check OFFLINE_DEPS_FR.md for exact GitHub ZIP links.")
        endif()
    endforeach()
    set(FETCHCONTENT_FULLY_DISCONNECTED ON CACHE BOOL "Never fetch pinned sources" FORCE)
    message(STATUS "w0uFF: using vendored offline sources for all dependencies")
endif()
