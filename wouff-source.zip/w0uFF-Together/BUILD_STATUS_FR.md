# Etat de compilation — w0uFF Together v0.4.1

## Verdict

- **Aucune DLL w0uFF Together n'a ete compilee ou testee dans Chained Together 1.11.2.**
- Les tests natifs sans dependances peuvent etre executes hors ligne via :
  `cmake -S . -B build-tests -DWOUFF_TESTS_ONLY=ON && cmake --build build-tests && ctest --test-dir build-tests --output-on-failure`
- Le binaire complet requiert Windows + MSVC, la dependance ReturnOfModdingBase, utfcpp et le SDK Unreal correspondant a la version du jeu. Il reste a confirmer que ce dernier est encore compatible.
- La machine locale est Linux, avec clang-cl mais sans Windows SDK / MSVC et sans resolution DNS pour github.com : la compilation de la DLL du fork est BLOQUEE localement.

## Chemin pour une DLL sans compiler soi-meme

Le projet embarque `.github/workflows/wouff-windows-build.yml`. Sur un depot GitHub dedie au mod, il accepte soit les sources extraites, soit un unique fichier `wouff-source.zip` contenant le dossier `w0uFF-Together`. Il effectue des tests C++ natifs, puis tente une compilation MSVC x64 sur un runner Windows et depose un artefact `d3d12.dll`. Son declenchement est **manuel uniquement** (`workflow_dispatch`) pour ne pas consommer des minutes de CI sans action explicite. La compilation peut echouer (SDK ancien / signatures / dependencies). Un succes CI ne prouve pas le fonctionnement en jeu.

**Aucun deploiement sur un depot GitHub n'a ete effectue.** Aucun projet GitHub du mod n'etait accessible avec les permissions presentes ; les autres depots ne doivent pas etre modifies pour cette finalite.

## Correctifs v0.4.1

- Suppression du code de capture/relecture TAS et d'injection de commandes de mouvement/saut, et des anciennes manipulations d'horloge non utilisees.
- Synchronisation par mutex des snapshots de jeu et des demandes de teleportation (suppression de la synchronisation `volatile` non valide en C++).
- Controle des coordonnees avant une demande de teleportation et preservation de l'orientation de l'avatar durant le rappel.
- Aucun deplacement impose au partenaire. Chaine/physics non synchronisees ou reinitialisees.

## Test utilisateur (APRES obtention d'une DLL du fork)

Sauvegarder la `d3d12.dll` tierce fonctionnelle, remplacer par notre artefact en DX12, verifier menu INSERT, fly F7, checkpoint enregistre sur une surface sure, retour F8, orientation, saut/deplacement vanilla, absence de crash. Ensuite tester duo en session privee ; le partenaire n'est pas teleporte. Fournir le resultat de chaque etape et logs en cas d'echec.

## Resultats de controle (22/11/2026)

- `cmake -S . -B build-tests -DWOUFF_TESTS_ONLY=ON -G Ninja` : OK.
- `cmake --build build-tests` : OK.
- `ctest --test-dir build-tests --output-on-failure` : **3/3 tests OK**.
- CMake complet (Linux): **ECHEC**, clone de `ReturnOfModdingBase` impossible avec `Could not resolve host: github.com`. Meme si le reseau etait disponible, Linux ne fournit pas les outils MSVC/Windows SDK requis pour produire le DLL cible.
- Workflow GitHub Actions: YAML analyse syntaxiquement, **aucun run lance**. Etape finale verifie maintenant PE x64 et export `D3D12CreateDevice` avant publication de l'artefact de test.

## Mise à jour ultérieure — 22/11/2026 : dépendances maintenant complètes

Le constat « manque ReturnOfModdingBase / réseau DNS » ci-dessus décrit l'étape **précédente**. Les **17 sources complètes** ont désormais été fournies et installées. La configuration CMake complète sur Linux passe hors ligne ; la compilation Linux s'arrête sur `d3d11.h` (Windows SDK absent), pas sur une dépendance GitHub. Le workflow Windows MSVC reste non exécuté et aucune DLL w0uFF n'est créée. Voir `README_COMPILATION_OFFLINE_FR.md`.
