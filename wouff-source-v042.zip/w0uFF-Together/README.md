# w0uFF Together — Practice Studio

A customizable Windows mod for **Chained Together**, focusing on repeated practice of community-known cuts.

## Features

- Completely redesigned dark-violet w0uFF Together interface (`INSERT`) with Training, Flight, Visuals and Settings tabs.
- All gameplay-affecting features **off at the start of every launch**; enable individually under Settings.
- Optional Fly (`F7` when its module is enabled) and local-player teleport with repeat checkpoint (`F8`).
- 20 named cut slots with solo/duo guidance. Exact coordinates must be calibrated in-game.
- Vanilla movement and jump; no autobunnyhop, speed modification or replay injector.
- On-screen diagnostics to distinguish menu loading from a working Unreal tick and pawn detection.

## Installation and testing

A Windows build should produce `d3d12.dll` via GitHub Actions. Back up the existing `d3d12.dll` first. Put ours beside `ChainedTogether-Win64-Shipping.exe` in `ChainedTogether/Binaries/Win64` and launch in DX12. Do **not** assume compatibility with 1.11.2 solely because the DLL builds.

1. Open with `INSERT`. Go to Settings and read Runtime diagnostics.
2. Verify tick callbacks increase and `Local pawn` shows FOUND before enabling Fly/Teleport.
3. Enable Fly; test in a private solo game with `F7`. Disable before returning to normal play.
4. Enable Teleport; capture and recall a safe position with `F8`.
5. Only then test co-op in a private lobby: chain state is not automatically synchronized.

If `Unreal tick callbacks: 0`, or if no pawn is detected, **do not attempt repeated gameplay actions**. Report the numbers and status.

## Source and license

Source code is distributed under GPL-3.0, with original provenance explained in [NOTICE.md](NOTICE.md). The project derives from UnchainedTogether by xiaoxiao921 and includes third-party code and generated game SDK. It must **not** be represented as entirely authored by w0uFF.
