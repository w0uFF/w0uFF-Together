# w0uFF Together v0.4.2 — suivi

- Menu fonctionne dans Chained Together 1.11.2 selon le test utilisateur de v0.4.1 ; Fly et téléportation ne fonctionnent pas.
- Nouvelle v0.4.2 : interface w0uFF Practice Studio, modules OFF à chaque démarrage, retrait Unlock Wings, diagnostics tick/pawn, nom du projet rebrandé et attributions conservées.
- Le hook Unreal dépend toujours d'une signature ancienne ; la compatibilité avec 1.11.2 n'est pas établie. Les compteurs de diagnostic servent à isoler l'échec ; aucun correctif non vérifié d'offset/hook n'a été introduit.
- Test C++ et compilation Windows CI requis. Après build, tests dans le jeu requis.
