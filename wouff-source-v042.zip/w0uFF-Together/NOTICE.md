# Attribution and provenance

w0uFF Together is an independently branded adaptation built on the GPL-3.0-licensed project **UnchainedTogether** by **xiaoxiao921** (original copyright © 2024) and third-party dependencies.

The w0uFF Practice Studio interface, checkpoint catalogue, feature gating, diagnostics and subsequent modifications are separately developed additions. The remaining original source code is **not** claimed as wholly written by w0uFF.

The original GPL-3.0 license in `LICENSE` remains in effect. Keep corresponding source and attribution available when distributing modified binaries. Third-party components retain their respective copyright and license notices.
